# Premier League GitHub Actions deployment

1. Create a **private** GitHub repository. Add `.github/workflows/epl-sync.yml` and `scripts/epl_sync.py` at the exact paths shown.
2. Repository → Settings → Secrets and variables → Actions → New repository secret. Name it `FOOTBALL_DATA_TOKEN` and paste the token **there only**. Never commit it or send it in chat.
3. Repository → Actions → **EPL fixtures and results** → Run workflow. Open the completed run and download `epl-snapshot-<run-id>` under Artifacts. Inspect `latest.json`.
4. GitHub Actions also schedules it every 6 hours (UTC); scheduled runs can be delayed. Artifacts expire after 30 days, so this is **not** a permanent audit ledger. Do not use it as the sole store of historical evidence.

This starter only retrieves fixtures/results. It does not create prospective forecasts, freeze pre-kickoff policies, integrate xG or DraftKings odds, or place/approve bets. The existing v95 project has separate research validation tools that need a prospective ledger and data-source configuration. GitHub does not independently prove when forecasts were made just because a commit has a date.
