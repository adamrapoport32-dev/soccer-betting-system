"""Fetch Premier League fixtures/results only; no odds, picks or bet placement."""
import json, os, sys, time, urllib.request, urllib.error
from datetime import datetime, timezone
from pathlib import Path

API = 'https://api.football-data.org/v4/competitions/PL/matches'

def main():
    token = os.environ.get('FOOTBALL_DATA_TOKEN')
    if not token:
        raise SystemExit('Missing FOOTBALL_DATA_TOKEN GitHub Actions secret')
    request = urllib.request.Request(API, headers={'X-Auth-Token': token, 'Accept':'application/json', 'User-Agent':'soccer-betting-system-epl-sync'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            if response.geturl() != API:
                raise RuntimeError('Unexpected redirect')
            raw = response.read(5_000_001)
    except urllib.error.HTTPError as exc:
        raise SystemExit(f'football-data.org returned HTTP {exc.code}') from None
    if len(raw)>5_000_000: raise RuntimeError('Provider payload too large')
    payload=json.loads(raw)
    if not isinstance(payload.get('matches'), list): raise RuntimeError('Invalid fixture response')
    matches=[]
    for m in payload['matches']:
        matches.append({'id':m.get('id'),'utcDate':m.get('utcDate'),'status':m.get('status'),
            'homeTeam':{'id':m.get('homeTeam',{}).get('id'),'name':m.get('homeTeam',{}).get('name')},
            'awayTeam':{'id':m.get('awayTeam',{}).get('id'),'name':m.get('awayTeam',{}).get('name')},
            'score':m.get('score'),'matchday':m.get('matchday')})
    result={'competition':'PL','retrieved_at_utc':datetime.now(timezone.utc).isoformat(),
            'source':API,'match_count':len(matches),'matches':matches,
            'research_only':True,'official_bets_created':0}
    out=Path('artifacts/epl');out.mkdir(parents=True,exist_ok=True)
    (out/'latest.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(f'Fetched {len(matches)} Premier League matches; saved artifacts/epl/latest.json')

if __name__=='__main__': main()
